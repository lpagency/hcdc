$(document).ready(function() {
    'use strict';

    // New isntance of WallopSlider
    var photoSlider = new WallopSlider('.wallop-slider');

});
