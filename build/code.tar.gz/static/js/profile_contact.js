/*global $*/

'use strict';

$(document).ready(function(){
    $(document).on('click', '.btn-contact-submit', function(evt)
    {
        // add validations here
        // evt.preventDefault();
    });
});